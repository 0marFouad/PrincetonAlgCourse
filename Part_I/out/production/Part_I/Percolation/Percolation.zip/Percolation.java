
import edu.princeton.cs.algs4.WeightedQuickUnionUF;



public class Percolation {

    private int[][] grid;
    private int opened;
    private int n;
    private WeightedQuickUnionUF uf;
    private WeightedQuickUnionUF uf2;
    private int upperNode;
    private int lowerNode;
    private int fullNode;

    // creates n-by-n grid, with all sites initially blocked
    public Percolation(int n){
        if(n <= 0){
            throw new IllegalArgumentException();
        }
        //assume closed = 0;
        grid = new int[n][n];
        opened = 0;
        this.n = n;
        uf = new WeightedQuickUnionUF(n*n + 2);
        uf2 = new WeightedQuickUnionUF(n*n + 1);
        upperNode = n*n;
        lowerNode = n*n + 1;
        fullNode = n*n;
    }

    private boolean isValid(int row, int col){
        if(row <= 0 || row > n || col <= 0 || col > n){
            return false;
        }
        return true;
    }

    private int getNumber(int row,int col){
        return ((row-1)*n) + (col-1);
    }

    // opens the site (row, col) if it is not open already
    public void open(int row, int col){
        if(isOpen(row,col)){
            return;
        }
        if(!isValid(row,col)){
            throw new IllegalArgumentException();
        }
        if(row == 1){
            uf2.union(getNumber(row,col),fullNode);
            uf.union(getNumber(row,col), upperNode);
        }
        if(row == n){
            uf.union(getNumber(row,col),lowerNode);
        }
        if(isValid(row-1,col) && isOpen(row-1,col)){
            uf.union(getNumber(row,col),getNumber(row-1,col));
            uf2.union(getNumber(row,col),getNumber(row-1,col));
        }
        if(isValid(row+1,col) && isOpen(row+1,col)){
            uf.union(getNumber(row,col),getNumber(row+1,col));
            uf2.union(getNumber(row,col),getNumber(row+1,col));
        }
        if(isValid(row,col-1) && isOpen(row,col-1)){
            uf.union(getNumber(row,col),getNumber(row,col-1));
            uf2.union(getNumber(row,col),getNumber(row,col-1));
        }
        if(isValid(row,col+1) && isOpen(row,col + 1)){
            uf.union(getNumber(row,col),getNumber(row,col+1));
            uf2.union(getNumber(row,col),getNumber(row,col+1));
        }
        opened++;
        grid[row-1][col-1] = 1;
    }

    // is the site (row, col) open?
    public boolean isOpen(int row, int col){
        if(!isValid(row,col)){
            throw new IllegalArgumentException();
        }
        return grid[row-1][col-1] == 1;
    }

    // is the site (row, col) full?
    public boolean isFull(int row, int col){
        if(!isValid(row,col)){
            throw new IllegalArgumentException();
        }
        if(uf2.find(getNumber(row,col)) == uf2.find(fullNode)){
            return true;
        }
        return false;
    }

    // returns the number of open sites
    public int numberOfOpenSites(){
        return opened;
    }

    // does the system percolate?
    public boolean percolates(){
        if(uf.find(lowerNode) == uf.find(upperNode)){
            return true;
        }
        return false;
    }

    // test client (optional)
    public static void main(String[] args){
        Percolation p = new Percolation(8);
        p.open(1,3);
        p.open(1,4);
        p.open(1,5);
        p.open(2,1);
        p.open(2,4);
        p.open(2,5);
        p.open(2,6);
        p.open(2,7);
        p.open(2,8);
        p.open(3,1);
        p.open(3,2);
        p.open(3,3);
        p.open(3,6);
        p.open(3,7);
        p.open(4,3);
        p.open(4,4);
        p.open(4,6);
        p.open(4,7);
        p.open(4,8);
        p.open(5,2);
        p.open(5,3);
        p.open(5,4);
        p.open(5,6);
        p.open(5,7);
        p.open(6,2);
        p.open(6,7);
        p.open(6,8);
        p.open(7,1);
        p.open(7,3);
        p.open(7,5);
        p.open(7,6);
        p.open(7,7);
        p.open(7,8);
        p.open(8,1);
        p.open(8,2);
        p.open(8,3);
        p.open(8,4);
        p.open(8,6);
        for(int i=1;i<=8;i++){
            for(int j=1;j<=8;j++){
                if(!p.isFull(i,j)){
                    System.out.print("-----" + "\t");
                    continue;
                }
                System.out.print(p.isFull(i,j) + "\t");
            }
            System.out.println();
        }
        System.out.println(p.percolates());
    }
}
